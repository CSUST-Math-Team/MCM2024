function test_targets = None(train_patterns, train_targets, test_patterns, Params)

% Make no classifications (Dummy function)
% Inputs:
% 	training_patterns   - Train patterns
%	training_targets	- Train targets
%   test_patterns       - Test  patterns
%	Dummy	        	- Unused
%
% Outputs
%	test_targets        - Predicted targets

test_targets = zeros(1,size(test_patterns,2));