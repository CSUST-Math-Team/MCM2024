function c=divpdf_log(a,b);

c=a-log(b);
