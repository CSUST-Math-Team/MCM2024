function c=mulpdf(a,b);

c=a.*b;
c=c/sum(c);
